# AI Research Agent

## Setup

pip install -r requirements.txt

Create a .env file:

OPENAI_API_KEY=...
TAVILY_API_KEY=...

## Run

python research_agent.py

Output: research_report.md
